# ProjetOS  Realized by Iléona, Mathilde, Maxime, Daniel and Thomas

Projet OS ITII2

Réalisation du projet de Réveil.

Les .c sont dans /Projet_OS_Reveil/src/main

Les executables sont dans /Projet_OS_Reveil/bin

Note au meilleur prof : lire le document /Projet_OS_Reveil/docs/Projet_OS_CR.pdf
